// script.js - كامل الوظائف
let currentLang = localStorage.getItem('lang') || 'ar';
let currentTheme = localStorage.getItem('theme') || 'light';

// الترجمات
const translations = {
  ar: {
    title: "ERP-Sudan",
    subtitle: "نظام تخطيط موارد المؤسسات السوداني",    login: "تسجيل الدخول",
    username: "اسم المستخدم",
    password: "كلمة المرور",
    dashboard: "لوحة التحكم",
    dailyLabor: "عمال اليومية",
    pettyCash: "المنصرفات اليومية",
    goldMining: "تعدين الذهب",
    backup: "النسخ الاحتياطي",
    settings: "الإعدادات",
    logout: "تسجيل الخروج",
    addWorker: "إضافة عامل",
    workerName: "اسم العامل",
    profession: "المهنة",
    dailyWage: "الأجر اليومي (SDG)",
    attendanceDate: "تاريخ الحضور",
    present: "حاضر",
    addExpense: "إضافة منصرف",
    description: "الوصف",
    amount: "المبلغ (SDG)",
    category: "الفئة",
    newCycle: "دورة إنتاج جديدة",
    goldWeight: "كمية الذهب (جرام)",
    purity: "النقاء (%)",
    marketPrice: "السعر السوقي (SDG/جرام)",
    costs: "التكاليف",
    calculateProfit: "حساب الأرباح",
    backupNow: "تشغيل نسخة احتياطية الآن",
    restore: "استعادة",
    language: "اللغة",
    theme: "الوضع",
    lightMode: "الوضع النهاري",
    darkMode: "الوضع الليلي",
    copyright: "© 2026 ذوالنون عمران – جميع الحقوق محفوظة"
  },
  en: {
    title: "ERP-Sudan",
    subtitle: "Sudanese Enterprise Resource Planning System",
    login: "Login",
    username: "Username",
    password: "Password",
    dashboard: "Dashboard",
    dailyLabor: "Daily Labor",
    pettyCash: "Petty Cash",
    goldMining: "Gold Mining",
    backup: "Backup",
    settings: "Settings",
    logout: "Logout",
    addWorker: "Add Worker",
    workerName: "Worker Name",
    profession: "Profession",    dailyWage: "Daily Wage (SDG)",
    attendanceDate: "Attendance Date",
    present: "Present",
    addExpense: "Add Expense",
    description: "Description",
    amount: "Amount (SDG)",
    category: "Category",
    newCycle: "New Production Cycle",
    goldWeight: "Gold Weight (grams)",
    purity: "Purity (%)",
    marketPrice: "Market Price (SDG/gram)",
    costs: "Costs",
    calculateProfit: "Calculate Profit",
    backupNow: "Run Backup Now",
    restore: "Restore",
    language: "Language",
    theme: "Theme",
    lightMode: "Light Mode",
    darkMode: "Dark Mode",
    copyright: "© 2026 Dhul-Noon Omaran – All Rights Reserved"
  }
};

// تطبيق اللغة
function applyLanguage(lang) {
  currentLang = lang;
  localStorage.setItem('lang', lang);
  
  document.documentElement.setAttribute('lang', lang);
  document.documentElement.setAttribute('dir', lang === 'ar' ? 'rtl' : 'ltr');
  
  // تحديث النصوص
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (translations[lang][key]) {
      if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
        el.placeholder = translations[lang][key];
      } else {
        el.textContent = translations[lang][key];
      }
    }
  });
  
  // تحديث أزرار اللغة
  document.querySelectorAll('.lang-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.lang === lang);
  });
}

// تطبيق الوضعfunction applyTheme(theme) {
  currentTheme = theme;
  localStorage.setItem('theme', theme);
  document.body.setAttribute('data-theme', theme);
  
  const themeLabel = document.getElementById('themeLabel');
  const themeLabel2 = document.getElementById('themeLabel2');
  if (themeLabel) {
    themeLabel.textContent = theme === 'dark' 
      ? translations[currentLang].darkMode 
      : translations[currentLang].lightMode;
  }
  if (themeLabel2) {
    themeLabel2.textContent = theme === 'dark' 
      ? translations[currentLang].darkMode 
      : translations[currentLang].lightMode;
  }
  
  const toggle1 = document.getElementById('themeToggle');
  const toggle2 = document.getElementById('themeToggle2');
  const toggle3 = document.getElementById('themeToggle3');
  if (toggle1) toggle1.checked = (theme === 'dark');
  if (toggle2) toggle2.checked = (theme === 'dark');
  if (toggle3) toggle3.checked = (theme === 'dark');
}

// تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
  // تطبيق الإعدادات المحفوظة
  applyLanguage(currentLang);
  applyTheme(currentTheme);
  
  // ربط أحداث التبديل
  document.querySelectorAll('.lang-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      applyLanguage(btn.dataset.lang);
    });
  });
  
  // ربط مفاتيح الوضع
  ['themeToggle', 'themeToggle2', 'themeToggle3'].forEach(id => {
    const toggle = document.getElementById(id);
    if (toggle) {
      toggle.addEventListener('change', () => {
        applyTheme(toggle.checked ? 'dark' : 'light');
      });
    }
  });
  
  // محاكاة النماذج
  document.querySelectorAll('form').forEach(form => {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      alert(translations[currentLang].calculateProfit + '!');
    });
  });
  
  // التنقل
  document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
      link.classList.add('active');
      
      const target = link.getAttribute('href').substring(1);
      document.querySelectorAll('.content-section').forEach(sec => {
        sec.style.display = 'none';
      });
      document.getElementById(target).style.display = 'block';
    });
  });
  
  // تسجيل الدخول
  document.getElementById('loginForm')?.addEventListener('submit', (e) => {
    e.preventDefault();
    document.getElementById('login-screen').style.display = 'none';
    document.getElementById('main-app').style.display = 'flex';
  });
  
  // تفعيل القسم الأول
  if (document.getElementById('dashboard')) {
    document.querySelector('.nav-link[href="#dashboard"]').classList.add('active');
    document.getElementById('dashboard').style.display = 'block';
  }
});

// وظائف خاصة بالتعدين
function calculateProfit() {
  const weight = parseFloat(document.getElementById('goldWeight')?.value) || 0;
  const purity = parseFloat(document.getElementById('purity')?.value) || 0;
  const price = parseFloat(document.getElementById('marketPrice')?.value) || 0;
  
  const revenue = weight * (purity / 100) * price;
  alert(`${translations[currentLang].calculateProfit}: ${revenue.toLocaleString()} SDG`);
}
